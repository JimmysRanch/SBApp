/*
 * Shared utility functions and sample data for SBApp.
 * These helpers manage employee data in localStorage so that
 * changes persist across different pages of the application.
 */

// -----------------------------------------------------------------------------
// Supabase configuration and helpers
//
// This application uses localStorage as a primary data store for employee
// information. To synchronize employee data with Supabase, we define a few
// helper functions. If Supabase tables are available and the provided API
// credentials are valid, these helpers will transparently sync local changes
// with the remote database. Otherwise the application will continue to
// function purely from localStorage.

// TODO: Replace these constants with your own Supabase URL and anon key.
const SUPABASE_URL = 'https://tzbybtluhzntfhjexptw.supabase.co';
const SUPABASE_KEY =
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InR6YnlidGx1aHpudGZoamV4cHR3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTY0MTkxNzIsImV4cCI6MjA3MTk5NTE3Mn0.E-2Y9CupjktT67UwkCP3Bm7-cBDmkolk2RIo_sPyRHQ';

// Perform a Supabase API request. Automatically injects the API key and
// authorization headers. Returns a fetch() Response object. If a network
// error occurs the promise will be rejected and the caller should handle
// accordingly. See https://supabase.com/docs/reference/javascript/fetch for
// details on using PostgREST endpoints.
async function supabaseRequest(endpoint, options = {}) {
  const headers = options.headers ? { ...options.headers } : {};
  headers['apikey'] = SUPABASE_KEY;
  headers['Authorization'] = `Bearer ${SUPABASE_KEY}`;
  // If Accept header not set, default to JSON for GET requests
  if (!headers['Accept'] && (!options.method || options.method === 'GET')) {
    headers['Accept'] = 'application/json';
  }
  const url = `${SUPABASE_URL}/rest/v1/${endpoint}`;
  const opts = { ...options, headers };
  return fetch(url, opts);
}

// Fetch all employees from Supabase. Returns an array of employee objects
// or null if the request failed. When Row Level Security is enabled on the
// employees table, ensure that the anon key has the proper permissions to
// select all rows.
async function fetchEmployeesFromSupabase() {
  try {
    const res = await supabaseRequest('employees');
    if (!res.ok) {
      // If the table does not exist or the user lacks access, the response
      // will contain a JSON error. Log it for debugging but fall back to
      // localStorage without interrupting the UI.
      console.warn('Supabase fetchEmployees error', res.status, await res.text());
      return null;
    }
    const data = await res.json();
    return data;
  } catch (err) {
    console.warn('Supabase fetchEmployees network error', err);
    return null;
  }
}

// Upsert (insert or update) a single employee record in Supabase. Requires
// that the employees table exists and that the id column is defined as
// primary key. Uses PostgREST on_conflict parameter with Prefer header
// resolution=merge-duplicates to merge duplicates when the id matches. If the
// table does not exist or the request fails, the error is logged but the
// application continues to operate using localStorage.
async function upsertEmployeeSupabase(employee) {
  try {
    const res = await supabaseRequest(
      'employees?on_conflict=id',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // Merge duplicates if the record already exists
          Prefer: 'resolution=merge-duplicates',
        },
        // PostgREST allows passing an array for bulk upserts
        body: JSON.stringify([employee]),
      }
    );
    if (!res.ok) {
      console.warn('Supabase upsertEmployee error', res.status, await res.text());
    }
  } catch (err) {
    console.warn('Supabase upsertEmployee network error', err);
  }
}

// Replace all employee records in Supabase with the provided array. This uses
// upsert semantics in a loop. For large datasets consider batching the
// request. If Supabase is unreachable, this function silently fails.
async function replaceAllEmployeesSupabase(employees) {
  if (!Array.isArray(employees) || employees.length === 0) return;
  // Upsert each employee asynchronously but do not await in sequence to
  // minimise latency. Any errors will be logged by upsertEmployeeSupabase.
  employees.forEach((emp) => upsertEmployeeSupabase(emp));
}

// Synchronise localStorage from Supabase. If employees are returned from
// Supabase, they will replace the contents of localStorage. If Supabase
// returns null (e.g. table missing or network failure) then localStorage
// remains unchanged. Returns a promise that resolves when the sync completes.
async function syncFromSupabase() {
  const remoteEmployees = await fetchEmployeesFromSupabase();
  if (Array.isArray(remoteEmployees) && remoteEmployees.length > 0) {
    // Overwrite localStorage with remote data
    setEmployees(remoteEmployees);
  }
}

// -----------------------------------------------------------------------------
// LocalStorage fallback and sample seed data
//
// The functions below manage employee data in localStorage. When Supabase is
// available, updates are mirrored remotely via the helpers above. Otherwise
// localStorage remains the single source of truth.

// Initialize sample data if it does not already exist.
function loadSampleData() {
  if (!localStorage.getItem('employees')) {
    const employees = [
      {
        id: 'emp1',
        name: 'Richelle Burke',
        role: 'Groomer',
        photo: '',
        address: {
          line1: '123 Ranch Rd',
          city: 'Natalia',
          state: 'TX',
          zip: '78059',
        },
        emergencyContact: {
          name: 'Richele Burke',
          relation: 'Partner',
          phone: '+12145551234',
        },
        payRate: 22.0,
        payrollHistory: [
          {
            periodStart: '2025-08-30',
            periodEnd: '2025-09-12',
            hours: 38.5,
            overtime: 0,
            rate: 22.0,
            gross: 847.0,
            deductions: 0,
            net: 847.0,
            paid: false,
          },
          {
            periodStart: '2025-08-16',
            periodEnd: '2025-08-29',
            hours: 40.0,
            overtime: 2.0,
            rate: 22.0,
            gross: 924.0,
            deductions: 50.0,
            net: 874.0,
            paid: true,
          },
        ],
        schedule: {
          regular: {
            mon: ['09:00-17:00'],
            tue: ['09:00-17:00'],
            wed: [],
            thu: ['09:00-17:00'],
            fri: ['09:00-17:00'],
            sat: ['10:00-14:00'],
            sun: [],
          },
          exceptions: [
            {
              date: '2025-09-20',
              type: 'vacation',
            },
          ],
          requests: [
            {
              id: 'req1',
              date: '2025-09-27',
              reason: 'Wedding',
              status: 'pending',
            },
          ],
        },
        notes: [
          { ts: '2025-09-10', text: 'Strong with anxious dogs.' },
          { ts: '2025-08-05', text: 'Great customer feedback this week.' },
        ],
        lifetime: {
          hours: 1040,
          grooms: 520,
          revenue: 20000,
        },
      },
      {
        id: 'emp2',
        name: 'Alex Johnson',
        role: 'Assistant',
        photo: '',
        address: {
          line1: '456 Oak St',
          city: 'Natalia',
          state: 'TX',
          zip: '78059',
        },
        emergencyContact: {
          name: 'Sara Johnson',
          relation: 'Sister',
          phone: '+12145559876',
        },
        payRate: 18.0,
        payrollHistory: [
          {
            periodStart: '2025-08-30',
            periodEnd: '2025-09-12',
            hours: 32.0,
            overtime: 0,
            rate: 18.0,
            gross: 576.0,
            deductions: 0,
            net: 576.0,
            paid: false,
          },
        ],
        schedule: {
          regular: {
            mon: ['09:00-17:00'],
            tue: ['09:00-17:00'],
            wed: ['09:00-12:00'],
            thu: ['12:00-17:00'],
            fri: ['09:00-17:00'],
            sat: [],
            sun: [],
          },
          exceptions: [],
          requests: [],
        },
        notes: [],
        lifetime: {
          hours: 450,
          grooms: 200,
          revenue: 8000,
        },
      },
    ];
    localStorage.setItem('employees', JSON.stringify(employees));
  }
  // Always attempt to synchronise from Supabase on page load. This will
  // overwrite localStorage if remote data exists. We do not await the
  // promise here because many consumers of loadSampleData are not async; the
  // sync runs in the background and updates will be reflected the next time
  // data is read from localStorage.
  syncFromSupabase();
}

// Retrieve all employees
function getEmployees() {
  const raw = localStorage.getItem('employees');
  try {
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    console.error('Error parsing employees from localStorage', e);
    return [];
  }
}

// Retrieve a single employee by ID
function getEmployee(id) {
  return getEmployees().find((e) => e.id === id);
}

// Save all employees back to localStorage
function setEmployees(employees) {
  localStorage.setItem('employees', JSON.stringify(employees));
  // Attempt to persist all employees to Supabase. Failures are logged but do
  // not block local updates. See replaceAllEmployeesSupabase in this file.
  replaceAllEmployeesSupabase(employees);
}

// Update a single employee in storage
function updateEmployee(updated) {
  const employees = getEmployees();
  const idx = employees.findIndex((e) => e.id === updated.id);
  if (idx >= 0) {
    employees[idx] = updated;
    setEmployees(employees);
    // Persist the single employee to Supabase asynchronously
    upsertEmployeeSupabase(updated);
  }
}

// Helper to parse query parameters
function getQueryParam(name) {
  const params = new URLSearchParams(window.location.search);
  return params.get(name);
}

// Helper to format currency
function formatCurrency(value) {
  return value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

// Helper to format date strings nicely
function formatDate(dateStr) {
  const d = new Date(dateStr);
  const options = { year: 'numeric', month: 'short', day: 'numeric' };
  return d.toLocaleDateString('en-US', options);
}