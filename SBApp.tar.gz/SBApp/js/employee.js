/*
 * Page script for employee.html
 * Handles displaying employee information, notes, schedule preview,
 * and actions like marking payroll paid or approving requests.
 */

document.addEventListener('DOMContentLoaded', () => {
  loadSampleData();
  const empId = getQueryParam('id') || 'emp1';
  const employee = getEmployee(empId);
  if (!employee) {
    alert('Employee not found');
    return;
  }
  // Display header info
  document.getElementById('emp-name').textContent = employee.name;
  document.getElementById('emp-role').textContent = employee.role;
  const photoEl = document.getElementById('emp-photo');
  if (employee.photo) {
    photoEl.src = employee.photo;
  }
  // Display address
  const addr = employee.address;
  document.getElementById('emp-address').textContent = `${addr.line1}, ${addr.city}, ${addr.state} ${addr.zip}`;
  // Display emergency contact
  const ec = employee.emergencyContact;
  document.getElementById('emp-emergency').innerHTML = `${ec.name} (${ec.relation}) - <a href="tel:${ec.phone}">${ec.phone}</a>`;
  // Payroll snapshot (show latest period)
  const latestPeriod = employee.payrollHistory[0] || null;
  if (latestPeriod) {
    document.getElementById('emp-rate').textContent = formatCurrency(employee.payRate);
    document.getElementById('emp-hours').textContent = latestPeriod.hours;
    document.getElementById('emp-gross').textContent = formatCurrency(latestPeriod.gross);
    document.getElementById('emp-net').textContent = formatCurrency(latestPeriod.net);
    document.getElementById('payroll-status').textContent = latestPeriod.paid ? 'Paid' : 'Unpaid';
  }
  // Mark paid button
  document.getElementById('mark-paid-btn').addEventListener('click', () => {
    if (!latestPeriod) return;
    if (latestPeriod.paid) {
      alert('This period is already marked as paid.');
      return;
    }
    latestPeriod.paid = true;
    updateEmployee(employee);
    document.getElementById('payroll-status').textContent = 'Paid';
    alert('Payroll period marked as paid.');
  });
  // View full payroll
  document.getElementById('full-payroll-btn').addEventListener('click', () => {
    window.location.href = `payroll.html?id=${employee.id}`;
  });
  // Edit schedule
  document.getElementById('edit-schedule-btn').addEventListener('click', () => {
    window.location.href = `schedule.html?id=${employee.id}`;
  });
  // View history
  document.getElementById('view-history-btn').addEventListener('click', () => {
    window.location.href = `history.html?id=${employee.id}`;
  });

  // Call and message actions
  document.getElementById('call-btn').addEventListener('click', () => {
    // Attempt to call emergency contact phone number if available
    const phone = employee.emergencyContact && employee.emergencyContact.phone;
    if (phone) {
      window.location.href = `tel:${phone}`;
    } else {
      alert('No phone number available.');
    }
  });
  document.getElementById('message-btn').addEventListener('click', () => {
    const phone = employee.emergencyContact && employee.emergencyContact.phone;
    if (phone) {
      window.location.href = `sms:${phone}`;
    } else {
      alert('No phone number available.');
    }
  });
  document.getElementById('edit-btn').addEventListener('click', () => {
    window.location.href = `settings.html?id=${employee.id}`;
  });
  // Render schedule preview (regular schedule)
  renderSchedulePreview(employee);
  // Render requests
  renderRequests(employee);
  // Render notes
  renderNotes(employee);
  // Render lifetime summary
  renderSummary(employee);
  // Add note button
  document.getElementById('add-note-btn').addEventListener('click', () => {
    const textarea = document.getElementById('new-note');
    const text = textarea.value.trim();
    if (!text) {
      return;
    }
    const newNote = { ts: new Date().toISOString().split('T')[0], text };
    employee.notes.unshift(newNote);
    updateEmployee(employee);
    textarea.value = '';
    renderNotes(employee);
  });
});

function renderSchedulePreview(employee) {
  const container = document.getElementById('week-schedule');
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  container.innerHTML = '';
  days.forEach((dayKey, idx) => {
    const key = dayKey.toLowerCase().substring(0, 3);
    const times = employee.schedule.regular[key] || [];
    const dayDiv = document.createElement('div');
    dayDiv.className = 'day';
    dayDiv.innerHTML = `<strong>${dayKey}</strong><br />${times.length ? times.join('<br/>') : '<span style="color: #9ca3af">Off</span>'}`;
    container.appendChild(dayDiv);
  });
}

function renderRequests(employee) {
  const container = document.getElementById('requests-container');
  container.innerHTML = '';
  const requests = employee.schedule.requests || [];
  if (requests.length === 0) {
    container.textContent = 'No pending requests.';
    return;
  }
  requests.forEach((req) => {
    const reqDiv = document.createElement('div');
    reqDiv.style.display = 'flex';
    reqDiv.style.justifyContent = 'space-between';
    reqDiv.style.alignItems = 'center';
    reqDiv.style.padding = '8px 0';
    reqDiv.style.borderBottom = '1px solid #e5e7eb';
    const info = document.createElement('div');
    info.innerHTML = `<strong>${formatDate(req.date)}</strong> - ${req.reason}`;
    const actions = document.createElement('div');
    if (req.status && req.status !== 'pending') {
      // Show status text if already handled
      const statusSpan = document.createElement('span');
      statusSpan.className = 'status-tag ' + (req.status === 'approved' ? 'status-green' : 'status-pink');
      statusSpan.textContent = req.status.charAt(0).toUpperCase() + req.status.slice(1);
      actions.appendChild(statusSpan);
    } else {
      // Pending requests show approve/deny buttons
      const approveBtn = document.createElement('button');
      approveBtn.className = 'button small';
      approveBtn.textContent = 'Approve';
      const denyBtn = document.createElement('button');
      denyBtn.className = 'button small';
      denyBtn.style.background = 'var(--primary)';
      denyBtn.textContent = 'Deny';
      actions.appendChild(approveBtn);
      actions.appendChild(denyBtn);
      approveBtn.addEventListener('click', () => {
        req.status = 'approved';
        updateEmployee(employee);
        renderRequests(employee);
      });
      denyBtn.addEventListener('click', () => {
        req.status = 'denied';
        updateEmployee(employee);
        renderRequests(employee);
      });
    }
    reqDiv.appendChild(info);
    reqDiv.appendChild(actions);
    container.appendChild(reqDiv);
  });
}

function renderNotes(employee) {
  const list = document.getElementById('notes-list');
  list.innerHTML = '';
  employee.notes.forEach((note) => {
    const li = document.createElement('li');
    li.style.padding = '6px 0';
    li.innerHTML = `<em>${formatDate(note.ts)}</em>: ${note.text}`;
    list.appendChild(li);
  });
  if (employee.notes.length === 0) {
    list.innerHTML = '<li style="color: #9ca3af">No notes yet.</li>';
  }
}

// Render lifetime summary cards
function renderSummary(employee) {
  if (!employee.lifetime) return;
  const hoursEl = document.getElementById('total-hours');
  const groomsEl = document.getElementById('total-grooms');
  const revenueEl = document.getElementById('total-revenue');
  if (hoursEl) hoursEl.textContent = employee.lifetime.hours;
  if (groomsEl) groomsEl.textContent = employee.lifetime.grooms;
  if (revenueEl) revenueEl.textContent = `$${formatCurrency(employee.lifetime.revenue)}`;
}