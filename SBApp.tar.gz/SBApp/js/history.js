/*
 * Page script for history.html
 * Displays lifetime summary and a simple chart of hours worked over payroll periods.
 */

document.addEventListener('DOMContentLoaded', () => {
  loadSampleData();
  const empId = getQueryParam('id') || 'emp1';
  const employee = getEmployee(empId);
  if (!employee) {
    alert('Employee not found');
    return;
  }
  document.getElementById('history-emp-name').textContent = employee.name;
  const employeesLink = document.getElementById('employees-link');
  if (employeesLink) {
    employeesLink.href = `employee.html?id=${employee.id}`;
  }
  // Display lifetime stats
  document.getElementById('hist-hours').textContent = employee.lifetime.hours;
  document.getElementById('hist-grooms').textContent = employee.lifetime.grooms;
  document.getElementById('hist-revenue').textContent = `$${formatCurrency(employee.lifetime.revenue)}`;
  // Build chart data from payroll history (hours per period)
  const labels = employee.payrollHistory.map((p) => `${formatDate(p.periodStart)} to ${formatDate(p.periodEnd)}`);
  const hours = employee.payrollHistory.map((p) => p.hours);
  const ctx = document.getElementById('history-chart').getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels,
      datasets: [
        {
          label: 'Hours Worked',
          data: hours,
          backgroundColor: 'rgba(64, 171, 242, 0.6)',
        },
      ],
    },
    options: {
      scales: {
        y: {
          beginAtZero: true,
          title: {
            display: true,
            text: 'Hours',
          },
        },
        x: {
          title: {
            display: true,
            text: 'Pay Period',
          },
        },
      },
    },
  });
});