/*
 * Page script for payroll.html
 * Displays a table of all payroll periods for an employee and allows exporting to CSV or PDF,
 * and marking unpaid periods as paid.
 */

document.addEventListener('DOMContentLoaded', () => {
  loadSampleData();
  const empId = getQueryParam('id') || 'emp1';
  const employee = getEmployee(empId);
  if (!employee) {
    alert('Employee not found');
    return;
  }
  document.getElementById('payroll-emp-name').textContent = employee.name;
  // Populate employees link to return to employee page
  const employeesLink = document.getElementById('employees-link');
  if (employeesLink) {
    employeesLink.href = `employee.html?id=${employee.id}`;
  }
  renderPayrollTable(employee);
  document.getElementById('export-csv-btn').addEventListener('click', () => {
    exportPayrollToCSV(employee);
  });
  document.getElementById('export-pdf-btn').addEventListener('click', () => {
    exportPayrollToPDF(employee);
  });
});

function renderPayrollTable(employee) {
  const tbody = document.querySelector('#payroll-table tbody');
  tbody.innerHTML = '';
  employee.payrollHistory.forEach((period, index) => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${formatDate(period.periodStart)}</td>
      <td>${formatDate(period.periodEnd)}</td>
      <td>${period.hours}</td>
      <td>${period.overtime}</td>
      <td>$${formatCurrency(period.rate)}</td>
      <td>$${formatCurrency(period.gross)}</td>
      <td>$${formatCurrency(period.deductions)}</td>
      <td>$${formatCurrency(period.net)}</td>
      <td>${period.paid ? '<span class="status-tag status-green">Paid</span>' : '<span class="status-tag status-pink">Unpaid</span>'}</td>
      <td></td>
    `;
    // Add action button
    const actionTd = tr.querySelector('td:last-child');
    if (!period.paid) {
      const btn = document.createElement('button');
      btn.className = 'button small';
      btn.textContent = 'Mark Paid';
      btn.addEventListener('click', () => {
        period.paid = true;
        updateEmployee(employee);
        renderPayrollTable(employee);
      });
      actionTd.appendChild(btn);
    } else {
      actionTd.textContent = '-';
    }
    tbody.appendChild(tr);
  });
}

function exportPayrollToCSV(employee) {
  const rows = [];
  // Header
  rows.push(['Period Start', 'Period End', 'Hours', 'Overtime', 'Rate', 'Gross', 'Deductions', 'Net', 'Status']);
  employee.payrollHistory.forEach((period) => {
    rows.push([
      period.periodStart,
      period.periodEnd,
      period.hours,
      period.overtime,
      period.rate,
      period.gross,
      period.deductions,
      period.net,
      period.paid ? 'Paid' : 'Unpaid',
    ]);
  });
  const csvContent = rows
    .map((row) => row.map((v) => '"' + v + '"').join(','))
    .join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.setAttribute('href', url);
  link.setAttribute('download', `${employee.name.replace(/\s+/g, '_')}_payroll.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function exportPayrollToPDF(employee) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  doc.setFontSize(14);
  doc.text(`Payroll History for ${employee.name}`, 14, 20);
  // Table header
  const startY = 30;
  const colWidths = [25, 25, 15, 20, 15, 20, 20, 20, 20];
  const headers = ['Start', 'End', 'Hrs', 'OT', 'Rate', 'Gross', 'Deduct', 'Net', 'Status'];
  let y = startY;
  // Header row
  let x = 14;
  doc.setFontSize(10);
  headers.forEach((h, i) => {
    doc.text(h, x + 1, y);
    x += colWidths[i];
  });
  y += 6;
  // Body rows
  employee.payrollHistory.forEach((period) => {
    x = 14;
    const row = [
      period.periodStart,
      period.periodEnd,
      String(period.hours),
      String(period.overtime),
      `$${formatCurrency(period.rate)}`,
      `$${formatCurrency(period.gross)}`,
      `$${formatCurrency(period.deductions)}`,
      `$${formatCurrency(period.net)}`,
      period.paid ? 'Paid' : 'Unpaid',
    ];
    row.forEach((val, i) => {
      doc.text(val, x + 1, y);
      x += colWidths[i];
    });
    y += 6;
    // Add page if overflow
    if (y > 280) {
      doc.addPage();
      y = 20;
    }
  });
  doc.save(`${employee.name.replace(/\s+/g, '_')}_payroll.pdf`);
}