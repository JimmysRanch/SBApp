/*
 * Page script for schedule.html
 * Allows editing of regular hours and managing time-off requests for an employee.
 */

document.addEventListener('DOMContentLoaded', () => {
  loadSampleData();
  const empId = getQueryParam('id') || 'emp1';
  const employee = getEmployee(empId);
  if (!employee) {
    alert('Employee not found');
    return;
  }
  document.getElementById('schedule-emp-name').textContent = employee.name;
  const employeesLink = document.getElementById('employees-link');
  if (employeesLink) {
    employeesLink.href = `employee.html?id=${employee.id}`;
  }
  // Build form grid
  renderScheduleForm(employee);
  // Display request list
  renderRequestList(employee);
  // Form submission
  document.getElementById('schedule-form').addEventListener('submit', (e) => {
    e.preventDefault();
    saveScheduleChanges(employee);
  });
});

const weekdays = [
  { key: 'mon', label: 'Monday' },
  { key: 'tue', label: 'Tuesday' },
  { key: 'wed', label: 'Wednesday' },
  { key: 'thu', label: 'Thursday' },
  { key: 'fri', label: 'Friday' },
  { key: 'sat', label: 'Saturday' },
  { key: 'sun', label: 'Sunday' },
];

function renderScheduleForm(employee) {
  const grid = document.getElementById('edit-week-grid');
  grid.innerHTML = '';
  weekdays.forEach((day) => {
    const cell = document.createElement('div');
    cell.className = 'day';
    const label = document.createElement('div');
    label.style.fontWeight = 'bold';
    label.textContent = day.label;
    cell.appendChild(label);
    // For each time slot, create input fields; support up to 2 slots per day
    const times = employee.schedule.regular[day.key] || [];
    for (let i = 0; i < 2; i++) {
      const timeSlot = times[i] || '';
      const input = document.createElement('input');
      input.type = 'text';
      input.placeholder = 'HH:MM-HH:MM';
      input.value = timeSlot;
      input.className = 'time-input';
      input.dataset.day = day.key;
      input.dataset.index = i;
      cell.appendChild(input);
    }
    grid.appendChild(cell);
  });
}

function saveScheduleChanges(employee) {
  const inputs = document.querySelectorAll('input.time-input');
  const newSchedule = {};
  inputs.forEach((input) => {
    const day = input.dataset.day;
    const idx = parseInt(input.dataset.index);
    if (!newSchedule[day]) newSchedule[day] = [];
    const val = input.value.trim();
    if (val) {
      newSchedule[day][idx] = val;
    }
  });
  // Clean empty strings and undefined
  Object.keys(newSchedule).forEach((d) => {
    newSchedule[d] = newSchedule[d].filter((v) => v);
  });
  employee.schedule.regular = newSchedule;
  updateEmployee(employee);
  alert('Schedule updated successfully.');
  // Redirect back to employee page
  window.location.href = `employee.html?id=${employee.id}`;
}

function renderRequestList(employee) {
  const container = document.getElementById('request-list');
  container.innerHTML = '';
  const requests = employee.schedule.requests || [];
  if (requests.length === 0) {
    container.textContent = 'No requests.';
    return;
  }
  requests.forEach((req) => {
    const wrapper = document.createElement('div');
    wrapper.style.display = 'flex';
    wrapper.style.justifyContent = 'space-between';
    wrapper.style.alignItems = 'center';
    wrapper.style.padding = '8px 0';
    wrapper.style.borderBottom = '1px solid #e5e7eb';
    const info = document.createElement('div');
    info.innerHTML = `<strong>${formatDate(req.date)}</strong> - ${req.reason} (<em>${req.status}</em>)`;
    const actions = document.createElement('div');
    if (req.status === 'pending') {
      const approveBtn = document.createElement('button');
      approveBtn.className = 'button small';
      approveBtn.textContent = 'Approve';
      const denyBtn = document.createElement('button');
      denyBtn.className = 'button small';
      denyBtn.style.background = 'var(--primary)';
      denyBtn.textContent = 'Deny';
      approveBtn.addEventListener('click', () => {
        req.status = 'approved';
        updateEmployee(employee);
        renderRequestList(employee);
      });
      denyBtn.addEventListener('click', () => {
        req.status = 'denied';
        updateEmployee(employee);
        renderRequestList(employee);
      });
      actions.appendChild(approveBtn);
      actions.appendChild(denyBtn);
    } else {
      actions.textContent = '';
    }
    wrapper.appendChild(info);
    wrapper.appendChild(actions);
    container.appendChild(wrapper);
  });
}