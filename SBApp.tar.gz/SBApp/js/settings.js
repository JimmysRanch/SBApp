/*
 * Page script for settings.html
 * Allows editing of employee pay rate, address, and emergency contact.
 */

document.addEventListener('DOMContentLoaded', () => {
  loadSampleData();
  const empId = getQueryParam('id') || 'emp1';
  const employee = getEmployee(empId);
  if (!employee) {
    alert('Employee not found');
    return;
  }
  // Fill fields with existing values
  document.getElementById('settings-emp-name').textContent = employee.name;
  document.getElementById('pay-rate').value = employee.payRate;
  document.getElementById('address-line1').value = employee.address.line1 || '';
  document.getElementById('address-city').value = employee.address.city || '';
  document.getElementById('address-state').value = employee.address.state || '';
  document.getElementById('address-zip').value = employee.address.zip || '';
  document.getElementById('ec-name').value = employee.emergencyContact.name || '';
  document.getElementById('ec-relation').value = employee.emergencyContact.relation || '';
  document.getElementById('ec-phone').value = employee.emergencyContact.phone || '';
  // Form submission handler
  document.getElementById('settings-form').addEventListener('submit', (e) => {
    e.preventDefault();
    // Get values
    const rateVal = parseFloat(document.getElementById('pay-rate').value);
    if (!isNaN(rateVal)) {
      employee.payRate = rateVal;
    }
    employee.address.line1 = document.getElementById('address-line1').value;
    employee.address.city = document.getElementById('address-city').value;
    employee.address.state = document.getElementById('address-state').value;
    employee.address.zip = document.getElementById('address-zip').value;
    employee.emergencyContact.name = document.getElementById('ec-name').value;
    employee.emergencyContact.relation = document.getElementById('ec-relation').value;
    employee.emergencyContact.phone = document.getElementById('ec-phone').value;
    updateEmployee(employee);
    alert('Employee settings saved.');
    // Redirect back to employee page
    window.location.href = `employee.html?id=${employee.id}`;
  });
});